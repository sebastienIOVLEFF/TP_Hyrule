﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cartes
{
    public class CAttaque : Carte
    {
        public CAttaque(string Nom, int Duree, int ID, int degat) : base(Nom, Duree, ID)
        {
            this.Degat = degat;
        }
        //methodes
        public override string Stats()
        {
            return $"{Nom} : {Degat} dégats";
        }
        //proprietes
        public int Degat { get; set; }
    }
}
