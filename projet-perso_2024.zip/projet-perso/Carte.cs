﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cartes
{
    public class Carte(string nom, int duree, int ID)
    {
        //methodes
        public virtual string Stats() { return $"{Nom}"; }

        //proprietes

        public virtual string? Nom { get; protected set; } = nom;
        public virtual int Duree { get; protected set; } = duree;
        public virtual int ID { get; protected set;} = ID;
    }
}
