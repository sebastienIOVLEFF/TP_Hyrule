﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListeCarte
{
    internal class DeplacementdDeCarte
    {
        public DeplacementdDeCarte() { }
        public void Pioche() 
        {
            int r;

            r = new Random().Next(1, 5);
            ListCarte.Main.Add(ListCarte.ListeDeck[r]);
        }
    }
}
