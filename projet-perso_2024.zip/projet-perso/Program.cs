﻿using System;
using System.Collections.Generic;
using Cartes;
using ListeCarte;

namespace game
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DeplacementdDeCarte zzz = new();
            CAttaque C1 = new CAttaque("coup", 1,1, 10);
            Console.WriteLine(C1.Stats());
            /*for (int i = 0; i < ListCarte.ListeDeck.Count; i++)
            {
                Console.WriteLine(ListCarte.ListeDeck[i].Stats());
            }*/
            zzz.Pioche();
            Console.WriteLine(ListCarte.Main[0].Stats());



            Console.ReadKey();
        }
    }
}