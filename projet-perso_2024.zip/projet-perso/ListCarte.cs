﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cartes;
namespace ListeCarte
{
    internal class ListCarte
    {
        static CAttaque C2 = new("coup", 1,2, 10);
        static CAttaque C3 = new("coup", 1,3, 14);
        static CAttaque C4 = new("coup", 1,4, 13);
        static CAttaque C5 = new("coup", 1,5, 19);
        static CAttaque C6 = new("coup", 1,6, 11);
        static CAttaque C7 = new("coup", 1,7, 18);
        public static List<Carte> ListeDeck = [C2, C3, C4, C5, C6, C7];
        public static List<Carte> Main = [];
    }
}
